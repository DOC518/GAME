#include <iostream>
#include <vector>

const int BOARD_SIZE = 19;

enum Stone { EMPTY, BLACK, WHITE };

void initializeBoard(std::vector<std::vector<Stone>>& board) {
    for (int i = 0; i < BOARD_SIZE; ++i) {
        std::vector<Stone> row(BOARD_SIZE, EMPTY);
        board.push_back(row);
    }
}

void printBoard(const std::vector<std::vector<Stone>>& board) {
    std::cout << "  ";
    for (int i = 0; i < BOARD_SIZE; ++i) {
        std::cout << (i < 10 ? " " : "") << i << " ";
    }
    std::cout << std::endl;

    for (int i = 0; i < BOARD_SIZE; ++i) {
        std::cout << (i < 10 ? " " : "") << i << " ";
        for (int j = 0; j < BOARD_SIZE; ++j) {
            if (board[i][j] == BLACK) {
                std::cout << "B ";
            }
            else if (board[i][j] == WHITE) {
                std::cout << "W ";
            }
            else {
                std::cout << ". ";
            }
        }
        std::cout << std::endl;
    }
}

bool placeStone(std::vector<std::vector<Stone>>& board, int x, int y, Stone stone) {
    if (x < 0 || x >= BOARD_SIZE || y < 0 || y >= BOARD_SIZE) {
        std::cout << "Position out of bounds!" << std::endl;
        return false;
    }

    if (board[x][y] != EMPTY) {
        std::cout << "Position already occupied!" << std::endl;
        return false;
    }

    board[x][y] = stone;
    return true;
}

int main() {
    std::vector<std::vector<Stone>> board;
    initializeBoard(board);

    Stone currentPlayer = BLACK;
    bool gameRunning = true;

    while (gameRunning) {
        printBoard(board);

        int x, y;
        std::cout << "Player " << (currentPlayer == BLACK ? "Black" : "White") << " turn. Enter position (x y): ";
        std::cin >> x >> y;

        if (placeStone(board, x, y, currentPlayer)) {
            currentPlayer = (currentPlayer == BLACK) ? WHITE : BLACK;
        }

        // For simplicity, this example does not handle game ending conditions or full game rules.
    }

    return 0;
}
